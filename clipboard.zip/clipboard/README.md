# Tailwind test ddev.

`ddev start` will start a container for this.

you can use `ddev ssh` and then run npm and npx commands.

site should be available at https://tailwinddemo.ddev.site/

